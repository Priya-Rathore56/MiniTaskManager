import psutil

class ProcessManager:
    @staticmethod
    def terminate_process(pid):
        """Terminate a process by PID"""
        try:
            process = psutil.Process(pid)
            process.terminate()
            return True, f"Process {pid} terminated successfully"
        except psutil.NoSuchProcess:
            return False, f"Process {pid} not found"
        except psutil.AccessDenied:
            return False, f"Access denied to terminate process {pid}"
    
    @staticmethod
    def get_process_details(pid):
        """Get detailed information about a process"""
        try:
            process = psutil.Process(pid)
            details = {
                'name': process.name(),
                'status': process.status(),
                'cpu_percent': process.cpu_percent(),
                'memory_percent': process.memory_percent(),
                'create_time': process.create_time(),
                'exe': process.exe(),
                'username': process.username()
            }
            return True, details
        except psutil.NoSuchProcess:
            return False, f"Process {pid} not found"