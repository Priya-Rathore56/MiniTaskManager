import psutil

class SystemMonitor:
    def __init__(self):
        self.net_prev = 0
    
    def get_system_usage(self):
        """Get current system resource usage"""
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent
        disk = psutil.disk_usage('/').percent
        
        # Calculate network usage in MB
        net_current = psutil.net_io_counters().bytes_sent + psutil.net_io_counters().bytes_recv
        net_usage = (net_current - self.net_prev) / (1024 * 1024)  # MB
        self.net_prev = net_current
        
        return cpu, ram, disk, max(0, net_usage)
    
    def get_processes_info(self):
        """Get information about running processes"""
        apps_data = []
        bg_data = []
        
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            try:
                name = proc.info['name'] or "Unknown"
                cpu = proc.info['cpu_percent'] or 0
                mem = f"{proc.info['memory_percent'] or 0:.1f}"
                
                process_data = ("🟢", name, proc.info['pid'], cpu, mem)
                
                # Separate apps vs background based on resource usage
                if cpu > 1.5 or float(mem) > 1.0:
                    apps_data.append(process_data)
                else:
                    bg_data.append(process_data)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        
        return apps_data, bg_data