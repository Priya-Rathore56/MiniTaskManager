import tkinter as tk
from ui.interface import TaskManagerUI
from monitor.system_info import SystemMonitor

class MiniTaskManager:
    def __init__(self):
        self.root = tk.Tk()
        self.ui = TaskManagerUI(self.root)
        self.monitor = SystemMonitor()
        
        # Start updates
        self.update_ui()
    
    def update_ui(self):
        """Update UI with latest system information"""
        try:
            # Update graphs
            system_data = self.monitor.get_system_usage()
            self.ui.update_graphs(system_data)
            
            # Update process tables
            processes_data = self.monitor.get_processes_info()
            self.ui.update_process_tables(processes_data)
            
        except Exception as e:
            print(f"Error updating UI: {e}")
        
        # Schedule next update
        self.root.after(1000, self.update_ui)
    
    def run(self):
        """Start the application"""
        self.root.mainloop()

if __name__ == "__main__":
    app = MiniTaskManager()
    app.run()