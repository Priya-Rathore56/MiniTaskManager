import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class TaskManagerUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Mini Task Manager")
        self.root.geometry("1200x750")
        self.root.configure(bg="#F2F2F2")
        
        self.cpu_data, self.ram_data, self.disk_data, self.net_data = [], [], [], []
        
        self.setup_ui()
    
    def setup_ui(self):
        # === HEADER ===
        title = tk.Label(self.root, text="System Resource Monitor", 
                        font=("Segoe UI", 20, "bold"), bg="#F2F2F2")
        title.pack(pady=10)
        
        # === GRAPH AREA ===
        self.setup_graphs()
        
        # === PROCESS TABLES ===
        self.setup_process_tables()
    
    def setup_graphs(self):
        self.fig, self.axes = plt.subplots(1, 4, figsize=(10, 3))
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        self.canvas.get_tk_widget().pack()
    
    def setup_process_tables(self):
        frame_main = tk.Frame(self.root, bg="#F2F2F2")
        frame_main.pack(fill="both", expand=True, pady=10)
        
        # Apps Table
        label_apps = tk.Label(frame_main, text="Apps", 
                             font=("Segoe UI", 14, "bold"), bg="#F2F2F2")
        label_apps.pack(anchor="w", padx=20)
        
        cols = ("Icon", "Name", "PID", "CPU %", "Memory %")
        self.tree_apps = ttk.Treeview(frame_main, columns=cols, show="headings", height=10)
        for col in cols:
            self.tree_apps.heading(col, text=col)
            self.tree_apps.column(col, width=150, anchor="center")
        self.tree_apps.pack(fill="x", padx=20, pady=5)
        
        # Background Processes Table
        label_bg = tk.Label(frame_main, text="Background Processes", 
                           font=("Segoe UI", 14, "bold"), bg="#F2F2F2")
        label_bg.pack(anchor="w", padx=20)
        
        self.tree_bg = ttk.Treeview(frame_main, columns=cols, show="headings", height=10)
        for col in cols:
            self.tree_bg.heading(col, text=col)
            self.tree_bg.column(col, width=150, anchor="center")
        self.tree_bg.pack(fill="x", padx=20, pady=5)
    
    def update_graphs(self, system_data):
        """Update graphs with new system data"""
        cpu, ram, disk, net = system_data
        
        self.cpu_data.append(cpu)
        self.ram_data.append(ram)
        self.disk_data.append(disk)
        self.net_data.append(net)
        
        if len(self.cpu_data) > 20:
            self.cpu_data.pop(0); self.ram_data.pop(0)
            self.disk_data.pop(0); self.net_data.pop(0)
        
        titles = ["CPU %", "RAM %", "Disk %", "Network (MB)"]
        datas = [self.cpu_data, self.ram_data, self.disk_data, self.net_data]
        colors = ["blue", "green", "orange", "red"]
        
        for ax, data, title, color in zip(self.axes, datas, titles, colors):
            ax.clear()
            ax.plot(data, color=color)
            ax.set_title(title)
            ax.set_ylim(0, 100 if "MB" not in title else max(10, max(data) if data else 0))
            ax.grid(True)
        
        self.canvas.draw()
    
    def update_process_tables(self, processes_data):
        """Update process tables with new process data"""
        apps_data, bg_data = processes_data
        
        # Clear existing data
        for tree in [self.tree_apps, self.tree_bg]:
            for row in tree.get_children():
                tree.delete(row)
        
        # Add apps data
        for proc in apps_data:
            self.tree_apps.insert("", "end", values=proc)
        
        # Add background processes data
        for proc in bg_data:
            self.tree_bg.insert("", "end", values=proc)